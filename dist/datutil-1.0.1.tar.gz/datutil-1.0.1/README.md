# DATUTIL PACKAGE FOR PYTHON
----------
### Main
This package contains helper functions for common data science processes.

It is still a work in progress, so expect more to be added, and need 
to be updated frequently. 
