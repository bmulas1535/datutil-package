"""
Initialize package contents

-- This process automatically imports submodules! --
"""

import core
import core.utility

